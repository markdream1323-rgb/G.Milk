// Minimal SMTP client (no dependencies): implicit TLS (port 465) or plain (for local tests),
// AUTH LOGIN, one HTML+text email with optional attachments.
import net from 'node:net';
import tls from 'node:tls';

const b64 = (value) => Buffer.from(value).toString('base64');
const wrap76 = (value) => value.replace(/(.{76})/g, '$1\r\n');
const crlf = (text) => text.replace(/\r?\n/g, '\r\n');
const encodeHeader = (text) => (/^[\x20-\x7e]*$/.test(text) ? text : `=?UTF-8?B?${b64(text)}?=`);

export function buildMime({ from, to, subject, text, html, attachments = [] }) {
  const id = Math.random().toString(36).slice(2);
  const mixed = `mixed_${id}`;
  const alt = `alt_${id}`;
  const lines = [
    `From: ${from}`,
    `To: ${to}`,
    `Subject: ${encodeHeader(subject)}`,
    `Date: ${new Date().toUTCString()}`,
    'MIME-Version: 1.0',
    `Content-Type: multipart/mixed; boundary="${mixed}"`,
    '',
    `--${mixed}`,
    `Content-Type: multipart/alternative; boundary="${alt}"`,
    '',
    `--${alt}`,
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    wrap76(b64(text)),
    `--${alt}`,
    'Content-Type: text/html; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
    '',
    wrap76(b64(html)),
    `--${alt}--`,
  ];
  for (const file of attachments) {
    lines.push(
      `--${mixed}`,
      `Content-Type: ${file.contentType}; name="${file.filename}"`,
      'Content-Transfer-Encoding: base64',
      `Content-Disposition: attachment; filename="${file.filename}"`,
      '',
      wrap76(file.content.toString('base64'))
    );
  }
  lines.push(`--${mixed}--`, '');
  return crlf(lines.join('\n'));
}

export function sendMail({ host, port, secure = true, user, pass, from, to, subject, text, html, attachments }) {
  return new Promise((resolve, reject) => {
    const socket = secure ? tls.connect({ host, port, servername: host }) : net.connect({ host, port });
    socket.setTimeout(30000);

    let buffer = '';
    let current = [];
    const replies = [];
    let waiter = null;
    let failure = null;
    let finished = false;

    const finish = (err) => {
      if (finished) return;
      finished = true;
      socket.destroy();
      if (err) reject(err);
      else resolve();
    };

    const fail = (err) => {
      failure = err;
      if (waiter) {
        const w = waiter;
        waiter = null;
        w.reject(err);
      }
    };

    socket.on('data', (chunk) => {
      buffer += chunk.toString('utf8');
      let i;
      while ((i = buffer.indexOf('\r\n')) !== -1) {
        const line = buffer.slice(0, i);
        buffer = buffer.slice(i + 2);
        current.push(line);
        if (/^\d{3}( |$)/.test(line)) {
          replies.push({ code: Number(line.slice(0, 3)), text: current.join(' | ') });
          current = [];
          if (waiter) {
            const w = waiter;
            waiter = null;
            w.resolve(replies.shift());
          }
        }
      }
    });
    socket.on('error', fail);
    socket.on('timeout', () => fail(new Error('SMTP connection timed out')));
    socket.on('close', () => fail(new Error('SMTP connection closed unexpectedly')));

    const read = () =>
      new Promise((res, rej) => {
        if (replies.length) return res(replies.shift());
        if (failure) return rej(failure);
        waiter = { resolve: res, reject: rej };
        return undefined;
      });
    const send = (line) => socket.write(`${line}\r\n`);
    const expect = async (codes) => {
      const reply = await read();
      if (!codes.includes(reply.code)) throw new Error(`SMTP ${reply.code}: ${reply.text}`);
      return reply;
    };

    (async () => {
      await expect([220]);
      send('EHLO gmilk-orders');
      await expect([250]);
      if (user) {
        send('AUTH LOGIN');
        await expect([334]);
        send(b64(user));
        await expect([334]);
        send(b64(pass));
        await expect([235]);
      }
      const bare = (address) => (address.match(/<([^>]+)>/) || [null, address])[1];
      send(`MAIL FROM:<${bare(from)}>`);
      await expect([250]);
      send(`RCPT TO:<${bare(to)}>`);
      await expect([250, 251]);
      send('DATA');
      await expect([354]);
      const message = buildMime({ from, to, subject, text, html, attachments }).replace(/^\./gm, '..');
      socket.write(`${message}\r\n.\r\n`);
      await expect([250]);
      send('QUIT');
      try {
        await read();
      } catch {
        /* the server may close right after QUIT */
      }
      finish();
    })().catch((err) => finish(err));
  });
}
