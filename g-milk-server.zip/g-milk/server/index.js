// G.Milk order server (no dependencies, Node 18+).
//  - POST /api/orders          customer sends order + payment screenshot -> owner gets an email
//  - GET  /api/orders/:id      customer's page checks status (needs the private token)
//  - GET/POST /admin/decide    links in the owner's email: Confirm or Reject the payment
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { sendMail } from './smtp.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const env = process.env;

const PORT = Number(env.PORT || 8787);
const DATA_DIR = env.DATA_DIR || path.join(here, 'data');
const PUBLIC_URL = (env.PUBLIC_URL || `http://localhost:${PORT}`).replace(/\/+$/, '');
const ALLOWED_ORIGIN = env.ALLOWED_ORIGIN || '*';
const ADMIN_SECRET = env.ADMIN_SECRET || '';
const MAIL_TO = env.MAIL_TO || 'awaisramzangujjar1323@gmail.com';
const SMTP = {
  host: env.SMTP_HOST || 'smtp.gmail.com',
  port: Number(env.SMTP_PORT || 465),
  secure: env.SMTP_SECURE !== 'false',
  user: env.SMTP_USER || '',
  pass: env.SMTP_PASS || '',
};
const MAIL_FROM = env.MAIL_FROM || (SMTP.user ? `G.Milk Orders <${SMTP.user}>` : 'G.Milk Orders <orders@gmilk.local>');
const METHODS = { easypaisa: 'Easypaisa', jazzcash: 'JazzCash' };
const MAX_BODY = 3 * 1024 * 1024;
const MAX_SHOT_BYTES = 1_500_000;
const ORDERS_PER_HOUR = Number(env.ORDERS_PER_HOUR || 8);

if (ADMIN_SECRET.length < 16) {
  console.error('Set ADMIN_SECRET to a random string of at least 16 characters.');
  process.exit(1);
}

fs.mkdirSync(path.join(DATA_DIR, 'shots'), { recursive: true });
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');

function loadOrders() {
  try {
    return JSON.parse(fs.readFileSync(ORDERS_FILE, 'utf8'));
  } catch {
    return {};
  }
}
let orders = loadOrders();
function saveOrders() {
  const tmp = `${ORDERS_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(orders, null, 2));
  fs.renameSync(tmp, ORDERS_FILE);
}

const escapeHtml = (v) =>
  String(v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pkr = (n) => `PKR ${Number(n).toLocaleString('en-PK')}`;
const sign = (id, action) => crypto.createHmac('sha256', ADMIN_SECRET).update(`${id}.${action}`).digest('hex');
function safeEqual(a, b) {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

// ---- tiny in-memory rate limit (per IP) ----
const hits = new Map();
function rateLimited(ip) {
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < 3_600_000);
  if (recent.length >= ORDERS_PER_HOUR) {
    hits.set(ip, recent);
    return true;
  }
  recent.push(now);
  hits.set(ip, recent);
  return false;
}
function clientIp(req) {
  if (env.TRUST_PROXY === '1') {
    const fwd = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (fwd) return fwd;
  }
  return req.socket.remoteAddress || 'unknown';
}

// ---- helpers ----
function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', ALLOWED_ORIGIN);
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}
function sendJson(res, status, body) {
  cors(res);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(body));
}
function sendHtml(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) {
        reject(Object.assign(new Error('Request too large.'), { status: 413 }));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function page(title, inner) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${escapeHtml(title)}</title>
<style>body{margin:0;background:#fffdf8;color:#1c2a21;font:16px/1.5 system-ui,sans-serif}main{max-width:560px;margin:0 auto;padding:20px 16px 40px}
h1{font-size:1.4rem;color:#183a24}.card{background:#fff;border:1px solid #dcefdf;border-radius:16px;padding:16px;margin:12px 0}
table{width:100%;border-collapse:collapse;font-size:.92rem}td{padding:4px 0;vertical-align:top}td:last-child{text-align:right}
img{max-width:100%;border-radius:12px;border:1px solid #dcefdf}.row{display:flex;gap:10px;margin-top:16px}
button{flex:1;min-height:48px;border:0;border-radius:999px;font:700 1rem system-ui;color:#fff;cursor:pointer}
.ok{background:#2c7141}.no{background:#b3261e}.pill{display:inline-block;padding:2px 10px;border-radius:999px;background:#f5ecd6;font-weight:700;font-size:.85rem}</style></head>
<body><main>${inner}</main></body></html>`;
}

function orderSummaryHtml(o) {
  const rows = o.items
    .map((i) => `<tr><td>${escapeHtml(i.name)} (${escapeHtml(i.size)}) &times; ${i.qty}</td><td>${pkr(i.price * i.qty)}</td></tr>`)
    .join('');
  return `<div class="card"><table>${rows}<tr><td><b>Total to receive</b></td><td><b>${pkr(o.subtotal)}</b></td></tr></table></div>
<div class="card"><table>
<tr><td>Customer</td><td>${escapeHtml(o.customer.name)}</td></tr>
<tr><td>Phone</td><td>${escapeHtml(o.customer.phone)}</td></tr>
${o.customer.email ? `<tr><td>Email</td><td>${escapeHtml(o.customer.email)}</td></tr>` : ''}
<tr><td>Address</td><td>${escapeHtml(o.customer.address)}</td></tr>
${o.customer.note ? `<tr><td>Note</td><td>${escapeHtml(o.customer.note)}</td></tr>` : ''}
<tr><td>Paid by</td><td>${METHODS[o.method]}</td></tr></table></div>`;
}

// ---- validation ----
function validateOrder(body) {
  const fail = (message) => ({ error: message });
  if (!body || typeof body !== 'object') return fail('Invalid request.');
  const c = body.customer || {};
  const text = (v, min, max) => typeof v === 'string' && v.trim().length >= min && v.trim().length <= max;
  if (!text(c.name, 2, 80)) return fail('Please enter your name.');
  if (typeof c.phone !== 'string' || !/^\+?[0-9][0-9\s-]{7,16}$/.test(c.phone.trim())) return fail('Please enter a valid phone number.');
  if (!text(c.address, 8, 300)) return fail('Please enter your delivery address.');
  if (c.note && !text(c.note, 0, 200)) return fail('The note is too long.');
  if (c.email && !(typeof c.email === 'string' && c.email.length <= 120)) return fail('Invalid email.');
  if (!METHODS[body.method]) return fail('Choose Easypaisa or JazzCash.');
  if (!Array.isArray(body.items) || body.items.length < 1 || body.items.length > 30) return fail('Your cart is empty.');
  const items = [];
  for (const i of body.items) {
    if (!i || !text(i.name, 1, 80) || !text(i.size, 1, 20)) return fail('Invalid item.');
    if (!Number.isInteger(i.qty) || i.qty < 1 || i.qty > 50) return fail('Invalid quantity.');
    if (typeof i.price !== 'number' || !(i.price >= 0) || i.price > 1_000_000) return fail('Invalid price.');
    items.push({ name: i.name.trim(), size: i.size.trim(), qty: i.qty, price: i.price });
  }
  const m = typeof body.shot === 'string' ? body.shot.match(/^data:image\/jpeg;base64,([A-Za-z0-9+/=]+)$/) : null;
  if (!m) return fail('Please upload your payment screenshot.');
  const shot = Buffer.from(m[1], 'base64');
  if (shot.length > MAX_SHOT_BYTES) return fail('The screenshot is too large.');
  if (!(shot[0] === 0xff && shot[1] === 0xd8 && shot[2] === 0xff)) return fail('The screenshot is not a valid image.');
  return {
    value: {
      customer: {
        name: c.name.trim(),
        phone: c.phone.trim(),
        email: c.email ? String(c.email).trim() : '',
        address: c.address.trim(),
        note: c.note ? String(c.note).trim() : '',
      },
      method: body.method,
      items,
      subtotal: items.reduce((s, i) => s + i.price * i.qty, 0),
      shot,
    },
  };
}

// ---- email to the shop owner ----
async function emailOwner(o, shot) {
  const link = (action) => `${PUBLIC_URL}/admin/decide?id=${encodeURIComponent(o.id)}&action=${action}&sig=${sign(o.id, action)}`;
  const itemsText = o.items.map((i) => `- ${i.name} (${i.size}) x ${i.qty} = ${pkr(i.price * i.qty)}`).join('\n');
  const text = [
    `New G.Milk order ${o.id} - payment to check`,
    '',
    `Paid by: ${METHODS[o.method]}`,
    `Amount to receive: ${pkr(o.subtotal)}`,
    '',
    `Customer: ${o.customer.name}`,
    `Phone: ${o.customer.phone}`,
    o.customer.email ? `Email: ${o.customer.email}` : '',
    `Address: ${o.customer.address}`,
    o.customer.note ? `Note: ${o.customer.note}` : '',
    '',
    itemsText,
    '',
    'The payment screenshot is attached. Check that the money reached your account, then:',
    `CONFIRM: ${link('confirm')}`,
    `REJECT:  ${link('reject')}`,
  ]
    .filter((l) => l !== '')
    .join('\n');
  const html = `<div style="font-family:system-ui,sans-serif;max-width:560px">
<h2 style="color:#183a24">New order ${escapeHtml(o.id)}</h2>
<p>Check that <b>${pkr(o.subtotal)}</b> reached your ${METHODS[o.method]} account. The screenshot is attached.</p>
${orderSummaryHtml(o)}
<p><a href="${link('confirm')}" style="display:inline-block;background:#2c7141;color:#fff;padding:12px 22px;border-radius:999px;text-decoration:none;font-weight:700">Review &amp; Confirm</a>
&nbsp;<a href="${link('reject')}" style="display:inline-block;background:#b3261e;color:#fff;padding:12px 22px;border-radius:999px;text-decoration:none;font-weight:700">Review &amp; Reject</a></p>
<p style="color:#666;font-size:13px">Each link opens a page where you press one more button to confirm your choice.</p></div>`;
  await sendMail({
    ...SMTP,
    from: MAIL_FROM,
    to: MAIL_TO,
    subject: `New G.Milk order ${o.id} - ${pkr(o.subtotal)} (${METHODS[o.method]}) - pending`,
    text,
    html,
    attachments: [{ filename: `${o.id}-payment.jpg`, contentType: 'image/jpeg', content: shot }],
  });
}

// ---- routes ----
async function handle(req, res) {
  const url = new URL(req.url, PUBLIC_URL);
  const { pathname } = url;

  if (req.method === 'OPTIONS') {
    cors(res);
    res.writeHead(204);
    return res.end();
  }
  if (pathname === '/health') return sendJson(res, 200, { ok: true });

  if (req.method === 'POST' && pathname === '/api/orders') {
    if (rateLimited(clientIp(req))) return sendJson(res, 429, { error: 'Too many orders. Please try again later.' });
    let body;
    try {
      body = JSON.parse(await readBody(req));
    } catch (err) {
      return sendJson(res, err.status || 400, { error: err.status === 413 ? 'The screenshot is too large.' : 'Invalid request.' });
    }
    const checked = validateOrder(body);
    if (checked.error) return sendJson(res, 400, { error: checked.error });
    const { shot, ...data } = checked.value;
    const id = `GM-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    const token = crypto.randomBytes(24).toString('hex');
    const order = { id, token, status: 'pending', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), ...data, emailed: false };
    fs.writeFileSync(path.join(DATA_DIR, 'shots', `${id}.jpg`), shot);
    orders[id] = order;
    saveOrders();
    try {
      await emailOwner(order, shot);
      order.emailed = true;
      saveOrders();
    } catch (err) {
      console.error(`Email for ${id} failed:`, err.message);
    }
    return sendJson(res, 201, { id, token, status: order.status, emailed: order.emailed });
  }

  const statusMatch = pathname.match(/^\/api\/orders\/([A-Za-z0-9-]+)$/);
  if (req.method === 'GET' && statusMatch) {
    const order = orders[statusMatch[1]];
    if (!order || !safeEqual(url.searchParams.get('token') || '', order.token)) {
      return sendJson(res, 404, { error: 'Order not found.' });
    }
    return sendJson(res, 200, { id: order.id, status: order.status, updatedAt: order.updatedAt });
  }

  if (pathname === '/admin/decide') {
    const params = req.method === 'POST' ? new URLSearchParams(await readBody(req)) : url.searchParams;
    const id = params.get('id') || '';
    const action = params.get('action') || '';
    const order = orders[id];
    if (!order || !['confirm', 'reject'].includes(action) || !safeEqual(params.get('sig') || '', sign(id, action))) {
      return sendHtml(res, 403, page('Invalid link', '<h1>This link is not valid</h1><p>Open the newest email for this order and try again.</p>'));
    }
    const verb = action === 'confirm' ? 'Confirm' : 'Reject';

    if (req.method === 'GET') {
      const shot = fs.existsSync(path.join(DATA_DIR, 'shots', `${id}.jpg`))
        ? fs.readFileSync(path.join(DATA_DIR, 'shots', `${id}.jpg`)).toString('base64')
        : '';
      return sendHtml(
        res,
        200,
        page(
          `${verb} ${id}`,
          `<h1>${verb} order ${escapeHtml(id)}?</h1>
<p>Current status: <span class="pill">${escapeHtml(order.status)}</span></p>
${orderSummaryHtml(order)}
${shot ? `<div class="card"><img alt="Payment screenshot" src="data:image/jpeg;base64,${shot}"></div>` : ''}
${
  order.status === 'pending'
    ? `<form method="post" action="/admin/decide"><input type="hidden" name="id" value="${escapeHtml(id)}"><input type="hidden" name="action" value="${action}"><input type="hidden" name="sig" value="${sign(id, action)}">
<div class="row"><button class="${action === 'confirm' ? 'ok' : 'no'}" type="submit">${action === 'confirm' ? 'Yes, payment received - Confirm' : 'No payment found - Reject'}</button></div></form>`
    : '<p>This order has already been decided. Nothing more to do.</p>'
}`
        )
      );
    }

    if (order.status !== 'pending') {
      return sendHtml(res, 200, page('Already decided', `<h1>Order ${escapeHtml(id)} is already ${escapeHtml(order.status)}</h1>`));
    }
    order.status = action === 'confirm' ? 'confirmed' : 'rejected';
    order.updatedAt = new Date().toISOString();
    saveOrders();
    return sendHtml(res, 200, page('Done', `<h1>Order ${escapeHtml(id)} is now ${escapeHtml(order.status)}</h1><p>The customer will see the new status on the website.</p>`));
  }

  return sendJson(res, 404, { error: 'Not found.' });
}

http
  .createServer((req, res) => {
    handle(req, res).catch((err) => {
      console.error('Unhandled error:', err);
      if (!res.headersSent) sendJson(res, 500, { error: 'Something went wrong.' });
      else res.end();
    });
  })
  .listen(PORT, () => console.log(`G.Milk order server listening on port ${PORT}`));
